package fr.ceri.list3ddisplay

import androidx.annotation.DrawableRes
import io.realm.Realm
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import org.bson.types.ObjectId

open class Liste3DDisplay (

    @PrimaryKey var id: ObjectId? = null,
    var nom: String? = null,
    @DrawableRes var idImage: Int? = null
    ) : RealmObject(){

    companion object {
        // noms des champs
        const val ID = "id"
        const val NOM = "nom"
        const val IDIMAGE = "idImage"

        // création d'une instance
        fun create(realm: Realm,
                   nom: String, @DrawableRes idImage: Int,id: ObjectId = ObjectId()
        ): ObjectId {
            val liste = realm.createObject(Liste3DDisplay::class.java, id)
            liste.nom = nom
            liste.idImage = idImage
            
            return id
        }
    }
}



