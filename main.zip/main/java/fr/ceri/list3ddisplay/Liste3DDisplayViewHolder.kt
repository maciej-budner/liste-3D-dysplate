package fr.ceri.list3ddisplay

import androidx.recyclerview.widget.RecyclerView
import fr.ceri.list3ddisplay.databinding.Liste3dDisplayBinding
import org.bson.types.ObjectId

class Liste3DDisplayViewHolder (val ui: Liste3dDisplayBinding) : RecyclerView.ViewHolder(ui.root){
    var displayId: ObjectId? = null
    var liste: Liste3DDisplay?
        get() = null
        set(liste) {
            if (liste == null) return
            displayId = liste.id
            ui.image.setImageResource(liste.idImage!!)
            ui.nom.text = liste.nom
        }
}