package fr.ceri.list3ddisplay

import android.util.Log
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import fr.ceri.list3ddisplay.databinding.Liste3dDisplayBinding
import org.bson.types.ObjectId

class Liste3DDisplayViewHolder (val ui: Liste3dDisplayBinding) : RecyclerView.ViewHolder(ui.root){
    var onItemClick: ((ObjectId?) -> Unit)? = null
    var displayId: ObjectId? = null
    var liste: Liste3DDisplay?
        get() = null
        set(liste) {
            if (liste == null) return
            displayId = liste.id
            ui.image.setImageResource(liste.idImage!!)
            ui.nom.text = liste.nom
        }
    init{
        ui.root.setOnClickListener(this::onClick)
    }
    private fun onClick(view: View?) {
        Log.i(displayId.toString(), "clic sur un view holder $displayId")
        onItemClick?.invoke(displayId)
    }
}