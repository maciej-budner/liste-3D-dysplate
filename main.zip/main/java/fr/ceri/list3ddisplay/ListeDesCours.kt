package fr.ceri.list3ddisplay

import android.content.Intent
import android.graphics.Bitmap

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.activity.enableEdgeToEdge

import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import fr.ceri.list3ddisplay.MainActivity.Companion.EXTRA_ID
import fr.ceri.list3ddisplay.MainActivity.Companion.EXTRA_NB_DISPLAY
import fr.ceri.list3ddisplay.databinding.ActivityListeDesCoursBinding
import io.realm.Realm
import io.realm.RealmResults
import org.bson.types.ObjectId
import java.io.File
import java.io.FileOutputStream

import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.widget.Toast



class ListeDesCours : AppCompatActivity() {
    lateinit var ui: ActivityListeDesCoursBinding
    lateinit var realm: Realm
    private lateinit var initReals: List3dApplication
    private lateinit var adapter: Liste3DAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityListeDesCoursBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(ui.root)
        initReals = List3dApplication()

        Realm.init(this)  // Initialisation de Realm ici
        realm = Realm.getDefaultInstance()//use Realm




        //maintenant faut le mettre dans la recyclerview
        // créer l'adaptateur

        creerAdaptater()

            // séparateur
        val dividerItemDecoration = DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL
        )
        ui.achat.addItemDecoration(dividerItemDecoration)


        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions

        //ecouteur
        adapter.onItemClick = this::onItemClick
        ui.cadi.setOnClickListener(this::retourArrier)
        ui.valider.setOnClickListener(this::validerCommande)
        ui.nomClient.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                // Code to handle text before change
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                // Code to handle text during change
                //si il y a pas de nom alors le bouton valider sera enable
                if(!(ui.nomClient.text.isEmpty())){
                    //si non vide
                    ui.valider.setEnabled(true)
                    ui.valider.textSize = 50F
                    ui.valider.text = "Valider"

                }
                else{
                    ui.valider.setEnabled(false)
                    ui.valider.textSize = 25F
                    ui.valider.text = "Un nom doit être mit"
                }
            }

            override fun afterTextChanged(s: Editable) {
                // Code to handle text after change

            }
        });

    }
    //lidée de la fonction vien de moi
    private fun creerAdaptater() {
        //aider de gpt de la à...{
        val safeIds = EXTRA_ID.filterNotNull()  // enlever les nulls

        val query = realm.where(Liste3DDisplay::class.java)

        if (safeIds.isNotEmpty()) {
            // Créer un OR dynamique
            var realmQuery = query.equalTo("id", safeIds[0])
            for (i in 1 until safeIds.size) {
                realmQuery = realmQuery.or().equalTo("id", safeIds[i])
            }
            val listeCours: RealmResults<Liste3DDisplay> = realmQuery.findAll()

            adapter = Liste3DAdapter(listeCours)
            ui.achat.adapter = adapter
            ui.achat.layoutManager = LinearLayoutManager(this)
            ui.achat.setHasFixedSize(true)
            ui.achat.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
        } else {
            // Aucun id sélectionné, afficher une liste vide
            val emptyResults: RealmResults<Liste3DDisplay> = realm.where(Liste3DDisplay::class.java)
                .equalTo("id", ObjectId()) // id qui n’existe pas
                .findAll()
            adapter = Liste3DAdapter(emptyResults)
            ui.achat.adapter = adapter
        }
        //}là, car je voyer pas comment mettre des image a la place des adresse d'image dans ma listeView
        //mais la c'est devenu un recyclerView
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun onItemClick(idDisplay: ObjectId?){
        EXTRA_ID.remove(idDisplay)
        EXTRA_NB_DISPLAY = EXTRA_NB_DISPLAY -1

        creerAdaptater()

    }

    private fun retourArrier(view: View){
        val intentA2 = Intent(this, MainActivity::class.java)
        startActivity(intentA2)
        finish()
    }
    private fun validerCommande(view: View){
        //on remet les extra a 0 ou vide

        creerPDF(ui.nomClient.text.toString())
        EXTRA_ID.clear()
        EXTRA_NB_DISPLAY = 0
        //une foie le pdf fait alors on peut fermet la fenetre
        retourArrier(view)
    }
    //fonction de gpt car j'ai jamais envoyer des donner pdf creer sauf on python
    private fun creerPDF(nomClient: String) {
        val safeIds = EXTRA_ID.filterNotNull()
        if (safeIds.isEmpty()) {
            Toast.makeText(this, "Aucune image sélectionné", Toast.LENGTH_SHORT).show()
            return
        }

        val pdfDocument = PdfDocument()
        val pageWidth = 595  // A4
        val pageHeight = 842
        val margin = 40
        val lineHeight = 25
        val imageHeight = 120
        val imageWidth = 120

        var pageNumber = 1
        var yPosition = margin

        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas
        val paint = android.graphics.Paint().apply { textSize = 14f }

        // Écrire le nom du client
        canvas.drawText("Nom du client : $nomClient", margin.toFloat(), yPosition.toFloat(), paint)
        yPosition += lineHeight + 10

        for (id in safeIds) {
            val cours = realm.where(Liste3DDisplay::class.java).equalTo("id", id).findFirst() ?: continue

            // Vérifier si on doit créer une nouvelle page
            if (yPosition + lineHeight + imageHeight > pageHeight - margin) {
                pdfDocument.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                yPosition = margin
            }

            // Ajouter le texte de l'image
            canvas.drawText("Nom image original : ${cours.nom}", margin.toFloat(), yPosition.toFloat(), paint)
            yPosition += lineHeight

            // Ajouter l'image du cours
            cours.idImage?.let { resId ->
                val bitmap = BitmapFactory.decodeResource(resources, resId)
                val scaled = Bitmap.createScaledBitmap(bitmap, imageWidth, imageHeight, true)
                canvas.drawBitmap(scaled, margin.toFloat(), yPosition.toFloat(), paint)
                yPosition += imageHeight + 10
            }
        }

        pdfDocument.finishPage(page)

        // Sauvegarder le PDF
        val timestamp = System.currentTimeMillis()
        val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "cours_{$nomClient}_$timestamp.pdf")

        try {
            pdfDocument.writeTo(FileOutputStream(file))
            Toast.makeText(this, "PDF créé : ${file.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Erreur lors de la création du PDF", Toast.LENGTH_SHORT).show()
        } finally {
            pdfDocument.close()
        }


    }


}