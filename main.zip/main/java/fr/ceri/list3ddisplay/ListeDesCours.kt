package fr.ceri.list3ddisplay

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import fr.ceri.list3ddisplay.MainActivity.Companion.EXTRA_ID

import fr.ceri.list3ddisplay.MainActivity.Companion.EXTRA_NB_DISPLAY
import fr.ceri.list3ddisplay.databinding.ActivityListeDesCoursBinding
import io.realm.Realm
import io.realm.RealmResults
import org.bson.types.ObjectId


class ListeDesCours : AppCompatActivity() {
    lateinit var ui: ActivityListeDesCoursBinding
    lateinit var realm: Realm
    private lateinit var initReals: List3dApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityListeDesCoursBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(ui.root)
        initReals = List3dApplication()

        Realm.init(this)  // Initialisation de Realm ici
        realm = Realm.getDefaultInstance()//use Realm

        //si il y a pas de nom alors le bouton valider sera enable
        if(!(ui.nomClient.text.isEmpty())){
            //si non vide
            ui.valider.setEnabled(true)

        }
        else{
            ui.valider.setEnabled(false)
        }

            //maintenant faut le mettre dans la recyclerview
            // créer l'adaptateur
        //aider de gpt de la à...{
        val safeIds = EXTRA_ID.filterNotNull()  // enlever les nulls

        val query = realm.where(Liste3DDisplay::class.java)
        if (safeIds.isNotEmpty()) {
            // Créer un OR dynamique
            var realmQuery = query.equalTo("id", safeIds[0])
            for (i in 1 until safeIds.size) {
                realmQuery = realmQuery.or().equalTo("id", safeIds[i])
            }
            val listeCours: RealmResults<Liste3DDisplay> = realmQuery.findAll()

            val adapter = Liste3DAdapter(listeCours)
            ui.achat.adapter = adapter
            ui.achat.layoutManager = LinearLayoutManager(this)
            ui.achat.setHasFixedSize(true)
            ui.achat.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
        } else {
            // Aucun id sélectionné, afficher une liste vide
            val emptyResults: RealmResults<Liste3DDisplay> = realm.where(Liste3DDisplay::class.java)
                .equalTo("id", ObjectId()) // id qui n’existe pas
                .findAll()
            val adapter = Liste3DAdapter(emptyResults)
            ui.achat.adapter = adapter
        }
        //}là, car je voyer pas comment mettre des image a la place des adresse d'image dans ma listeView
        //mais la c'est devenu un recyclerView





            // séparateur
        val dividerItemDecoration = DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL
        )
        ui.achat.addItemDecoration(dividerItemDecoration)



        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions


        //ecouteur
        ui.cadi.setOnClickListener(this::retourArrier)

    }
    override fun onDestroy() {
        super.onDestroy()
    }
    private fun retourArrier(view: View){
        val intentA2 = Intent(this, MainActivity::class.java)
        startActivity(intentA2)
        finish()
    }
}