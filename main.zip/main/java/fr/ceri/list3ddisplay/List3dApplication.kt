package fr.ceri.list3ddisplay
import android.app.Application
import io.realm.Realm
import io.realm.RealmConfiguration

class List3dApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Realm.getDefaultConfiguration() == null) {
            Realm.init(this)
            val config = RealmConfiguration.Builder()
                .name("my-realm")
                .deleteRealmIfMigrationNeeded()  // voir remarque
                .compactOnLaunch()
                .build()
            // set this config as the default realm
            Realm.setDefaultConfiguration(config)
        }
        // si nécessaire pour d'autres initialisations, récupérer la base
        val realm = Realm.getDefaultInstance()
        initList(realm)
    }

    fun initList(realm: Realm) {
        if(realm.where(Liste3DDisplay::class.java).count() == 0L){
        realm.executeTransactionAsync {
            // accès aux ressources
            val res = getResources()
            val noms = res.getStringArray(R.array.noms)
            val images = res.obtainTypedArray(R.array.idimages)
                // recopier les données dans la base Realm
                    for (i in 0..noms.size - 1) {
                        // constructeur avec tous les paramètres
                        Liste3DDisplay.create(
                            realm = it,
                            nom = noms[i],
                            idImage = images.getResourceId(i, R.drawable.undef)
                        )
                    }
                        // libérer les images (obligation Android)
            images.recycle()
        }}
    }
}

