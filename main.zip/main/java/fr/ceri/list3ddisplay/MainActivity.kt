package fr.ceri.list3ddisplay
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import fr.ceri.list3ddisplay.databinding.ActivityMainBinding
import io.realm.Realm

class MainActivity : AppCompatActivity() {
    lateinit var realm: Realm
    lateinit var ui: ActivityMainBinding
    private lateinit var initReals: List3dApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(ui.root)
        initReals = List3dApplication()



        Realm.init(this)  // Initialisation de Realm ici
        realm = Realm.getDefaultInstance()//use Realm

        // Masquer la barre de statut (status bar) et la barre de navigation
        val decorView = window.decorView
        val uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        decorView.systemUiVisibility = uiOptions


        val list = realm.where(Liste3DDisplay::class.java).findAll()
// créer l'adaptateur
        val adapter = Liste3DAdapter(list)

        ui.recycler.layoutManager = LinearLayoutManager(this)
        // fournir l'adaptateur au recycler
        ui.recycler.adapter = adapter

        //dimension
        ui.recycler.setHasFixedSize(true)
        // layout manager
        val lm: RecyclerView.LayoutManager = LinearLayoutManager(this)
        ui.recycler.layoutManager = lm

        // séparateur
        val dividerItemDecoration = DividerItemDecoration(this,
            DividerItemDecoration.VERTICAL
        )
        ui.recycler.addItemDecoration(dividerItemDecoration)

    }
    override fun onDestroy() {
        realm.close()
        super.onDestroy()
    }
}