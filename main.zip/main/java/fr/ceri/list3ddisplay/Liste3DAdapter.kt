package fr.ceri.list3ddisplay

import android.view.LayoutInflater
import android.view.ViewGroup
import io.realm.RealmResults
import org.bson.types.ObjectId

import android.view.View

import androidx.recyclerview.widget.RecyclerView
import fr.ceri.list3ddisplay.R
import fr.ceri.list3ddisplay.Liste3DDisplay
import fr.ceri.list3ddisplay.databinding.Liste3dDisplayBinding

class Liste3DAdapter(val liste: RealmResults<Liste3DDisplay>) :
    RecyclerView.Adapter<Liste3DDisplayViewHolder>(){
    var onItemClick: ((ObjectId?) -> Unit)? = null   // nullable
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Liste3DDisplayViewHolder {
        val ui=Liste3dDisplayBinding.inflate(LayoutInflater.from(parent.context),parent, false)
        return Liste3DDisplayViewHolder(ui)
    }

    override fun getItemCount(): Int {
        return liste.size
    }

    override fun onBindViewHolder(holder: Liste3DDisplayViewHolder, position: Int) {
        holder.liste = liste[position]
        holder.onItemClick= onItemClick
    }

    init {
        liste.addChangeListener { _, changeSet ->
            for (change in changeSet.deletionRanges) {
                notifyItemRangeRemoved(change.startIndex, change.length)
            }
            for (change in changeSet.insertionRanges) {
                notifyItemRangeInserted(change.startIndex, change.length)
            }
            for (change in changeSet.changeRanges) {
                notifyItemRangeChanged(change.startIndex, change.length)
            }
        }
    }
}